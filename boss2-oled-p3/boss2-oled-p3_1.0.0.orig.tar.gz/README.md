# allo_boss2_oled_p3

This python application code is modified for working with python3

some of thhe OS python3 by default available, remaining smbus,pil and Rpi.gpio packages need to install manually


ssh login 

cd /opt/

wget https://raw.githubusercontent.com/allocom/allo_boss2_oled_p3/main/boss2_oled_p3.tar.gz

tar -zxvf boss2_oled_p3.tar.gz

cd boss2_oled_p3

refer : https://github.com/allocom/allo_boss2_oled_p3/blob/main/boss2_oled_p3/README

