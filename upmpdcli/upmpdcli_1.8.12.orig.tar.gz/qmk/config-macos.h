
/* Define to 1 if you have the 'exp10' function */
#undef HAVE_EXP10

/* Define to the version of this package. */
#define UPMPDCLI_VERSION "1.8.12"

#include "src/conf_post.h"
