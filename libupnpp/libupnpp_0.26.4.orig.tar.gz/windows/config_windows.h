
#define PACKAGE_VERSION "0.26.3"

#define CONFIG_WINDOWS_INCLUDED 1

#include "libupnpp/conf_post.h"
