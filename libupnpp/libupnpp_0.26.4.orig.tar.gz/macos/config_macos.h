
#define PACKAGE_VERSION "0.26.3"

#include "libupnpp/conf_post.h"
