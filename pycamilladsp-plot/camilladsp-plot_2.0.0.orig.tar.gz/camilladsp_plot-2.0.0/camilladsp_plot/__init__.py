from camilladsp_plot.eval_filterconfig import eval_filter, eval_filterstep

VERSION="2.0.0"