#ifndef NOTICE_H
#define NOTICE_H

#define VERSION "trx 0.6.0"
#define COPYRIGHT "(C) Copyright 2020 Mark Hills <mark@xwax.org>\n" \
                  "(C) Copyright 2021 Tim Curtis <tim@moodeaudio.org>"
#endif
